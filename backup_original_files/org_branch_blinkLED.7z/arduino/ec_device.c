#include "xgeneral.h"
#include "ecat_timer.h"
#include "ec_device.h"

void ecat_add_event_to_device(struct ec_device *ec, 
		struct ecat_event* ev,
		void (*action)(void *), 
		void *__private)
{
	return;
}
