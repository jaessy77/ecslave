#ifndef __H_ECAT_PROTOCOL__ 
#define __H_ECAT_PROTOCOL__ 

void ecat_proto_init(ecat_slave * ecs);
void ecat_proto_cleanup(void);

#endif
