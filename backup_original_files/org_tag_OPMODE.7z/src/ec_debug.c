
void ec_printf(const char *str, ...){}
