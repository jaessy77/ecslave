#ifndef  __ECAT_NETPROTO_H__
#define __ECAT_NETPROTO_H__

int ecat_netproto_init(void);
void ecat_netproto_exit(void);

#endif
